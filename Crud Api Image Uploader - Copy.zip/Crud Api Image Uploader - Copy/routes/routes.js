const express = require("express");
const router = express.Router();
const User = require('../models/user');
const multer = require('multer');
const fs = require('fs')

// image uploader
var storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, './uploads');
  },
  filename: function(req, file, cb) {
    cb(null, file.fieldname + "_" + Date.now() + "_" + file.originalname);
  }
});

var upload = multer({
  storage: storage,
}).single("image");



// insert a user into the database route
router.post('/add', upload, async (req, res) => {
  try {
    const user = new User({
      name: req.body.name,
      email: req.body.email,
      phone: req.body.phone,
      image: req.file.filename,
    });

    await user.save();

    req.session.message = {
      type: 'success',
      message: 'User added successfully'
    };
    res.redirect("/");
  } catch (error) {
    res.json({ message: error.message, type: 'danger' });
  }
});

//get all user routes

router.get("/", async (req, res) => {
  try {
    const users = await User.find().exec();
    res.render('index', {
      title: 'Home Page',
      users: users,
    });
  } catch (err) {
    res.json({ message: err.message });
  }
});

router.get("/add", (req, res) => {
  res.render("add_user", { title: "Add Users" });
});

//edit an user route
router.get('/edit/:id', async (req, res) => {
  try {
     let id = req.params.id;

     // Use async/await to handle the promise returned by findById
     const user = await User.findById(id).exec();

     if (user == null) {
        // If the user is not found, redirect to the home page
        return res.redirect('/');
     }

     // If the user is found, render the 'edit_users' view with user data
     return res.render('edit_users', {
        title: "Edit User",
        user: user,
     });

  } catch (err) {
     // Handle errors, e.g., log the error and redirect to the home page
     console.error(err);
     return res.redirect('/');
  }
});

// update user route

router.post('/update/:id', upload, async (req, res) => {
  try {
    let id = req.params.id;
    let new_image = '';

    if (req.file) {
      new_image = req.file.filename;
      try {
        // Use path.join to construct the full path
        const filePath = path.join('./uploads/', req.body.old_image);
        fs.unlinkSync(filePath);
      } catch (err) {
        console.log(err);
      }
    } else {
      new_image = req.body.old_image;
    }

    const updatedUser = await User.findByIdAndUpdate(id, {
      name: req.body.name,
      email: req.body.email,
      phone: req.body.phone,
      image: new_image,
    });

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found', type: 'danger' });
    }

    req.session.message = {
      type: 'success',
      message: 'User updated successfully',
    };

    res.redirect('/');
  } catch (err) {
    res.status(500).json({ message: err.message, type: 'danger' });
  }
});

// delete the user
router.get('/delete/:id', async (req, res) => {
  try {
     let id = req.params.id;

     // Use async/await to handle the promise returned by findByIdAndDelete
     const result = await User.findByIdAndDelete(id);

     if (result && result.image !== '') {
        try {
           fs.unlinkSync('./uploads/' + result.image);
        } catch (err) {
           console.log(err);
        }
     }

     req.session.message = {
        type: 'success',
        message: 'User deleted successfully',
     };
     res.redirect('/');

  } catch (err) {
     res.json({ message: err.message });
  }
});






module.exports = router;
